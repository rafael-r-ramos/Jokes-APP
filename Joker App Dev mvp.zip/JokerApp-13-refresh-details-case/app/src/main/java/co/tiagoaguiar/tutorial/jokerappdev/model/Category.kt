package co.tiagoaguiar.tutorial.jokerappdev.model

data class Category(
  val name: String,
  val bgColor: Long
)
